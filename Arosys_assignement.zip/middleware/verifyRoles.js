const verifyRoles = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req?.body.user_role) return res.sendStatus(401);
    const rolesArray = [...allowedRoles];
    const result = JSON.parse(req.body.user_role)
      .map((role) => rolesArray.includes(role))
      .find((val) => val === true);
    if (!result) return res.sendStatus(401);
    next();
  };
};

module.exports = verifyRoles;
