const { OpenFgaClient } = require("@openfga/sdk"); // OR import { OpenFgaClient } from '@openfga/sdk';

const openFga = new OpenFgaClient({
  apiUrl: process.env.FGA_API_URL, // required, e.g. https://api.fga.example
});

const { id: storeId } = await openFga.createStore({
  name: "Arosys FGA Store",
});

const { allowed } = await fgaClient.check(
  {
    user: "user:bob",
    relation: "editor",
    object: "document:meeting_notes.doc",
  },
  {
    authorizationModelId: "01HVMMBCMGZNT3SED4Z17ECXCA",
  }
);
