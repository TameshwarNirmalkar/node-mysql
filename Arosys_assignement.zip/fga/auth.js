const { OpenFgaClient } = require("@openfga/sdk");

const fgaClient = new OpenFgaClient({
  apiUrl: process.env.FGA_API_URL, // required, e.g. https://api.fga.example
  storeId: process.env.FGA_STORE_ID,
  authorizationModelId: process.env.FGA_MODEL_ID, // Optional, can be overridden per request
});

const { authorization_model_id: id } = await fgaClient.writeAuthorizationModel({
  schema_version: "1.1",
  type_definitions: [
    {
      type: "user",
    },
    {
      type: "document",
      relations: {
        reader: {
          this: {},
        },
        writer: {
          this: {},
        },
        owner: {
          this: {},
        },
      },
      metadata: {
        relations: {
          reader: {
            directly_related_user_types: [
              {
                type: "user",
              },
            ],
          },
          writer: {
            directly_related_user_types: [
              {
                type: "user",
              },
            ],
          },
          owner: {
            directly_related_user_types: [
              {
                type: "user",
              },
            ],
          },
        },
      },
    },
  ],
});
// id = "01HVMMBCMGZNT3SED4Z17ECXCA"
