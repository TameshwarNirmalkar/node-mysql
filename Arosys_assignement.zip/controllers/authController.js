const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const db = require("../db");

const handleLogin = async (req, res) => {
  const { user_name, user_password } = req.body;

  if (!user_name || !user_password)
    return res
      .status(400)
      .json({ message: "Username and password are required." });

  const [rows, fields] = await db.query(
    `SELECT * FROM user WHERE UserName = ?`,
    [user_name]
  );

  if (!rows.length) {
    return res.status(401).json({ success: false, message: "Unauthorized" }); //Unauthorized
  }
  // evaluate password
  const match = await bcrypt.compare(user_password, rows[0].UserPassword);

  if (match) {
    const roles = JSON.parse(rows[0].UserRoles);
    // create JWTs
    const accessToken = jwt.sign(
      {
        UserInfo: {
          user_name: rows[0].UserName,
          user_roles: roles,
          user_firstname: rows[0].UserFirstName,
          user_lastname: rows[0].UserLastName,
        },
      },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: "1d" }
    );

    const refreshToken = jwt.sign(
      { user_name: rows[0].UserName },
      process.env.REFRESH_TOKEN_SECRET,
      { expiresIn: "3d" }
    );

    res.cookie("jwt", refreshToken, {
      httpOnly: true,
      sameSite: "None",
      secure: true,
      maxAge: 24 * 60 * 60 * 1000,
    });

    res.json({
      accessToken,
      refreshToken,
      success: true,
      message: "Authorized User",
    });
  } else {
    res.status(401).json({ success: false, message: "Unauthorized" });
  }
};

module.exports = { handleLogin };
