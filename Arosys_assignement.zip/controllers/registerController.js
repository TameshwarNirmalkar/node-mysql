const bcrypt = require("bcrypt");
const db = require("../db");

const handleNewUser = async (req, res) => {
  try {
    const { user_name, user_password, user_email } = req.body;

    const [rows, fields] = await db.query(
      `SELECT * FROM user WHERE UserName = ? OR UserEmail = ?`,
      [user_name, user_email]
    );
    if (!!rows.length) {
      return res.status(409).json({
        success: false,
        message: "User name or User email already exist.",
      });
    }

    const hashedPwd = await bcrypt.hash(user_password, 10);
    await db.query(
      "INSERT INTO user (UserEmail, UserPassword, UserName, UserRoles) VALUES (?, ?, ?, ?)",
      [user_email, hashedPwd, user_name, "[1003]"]
    );

    res
      .status(201)
      .json({ success: true, message: `New user ${user_name} created!` });
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Error on request" });
  }
};

module.exports = { handleNewUser };
