const bcrypt = require("bcrypt");
const db = require("../db");

// GET ALL USERS LIST
const getUsersList = async (req, res) => {
  try {
    const [rows, fields] = await db.query("SELECT * FROM user");
    if (rows.length === 0) {
      res.status(200).json({ success: true, message: "Empty table", user: [] });
    } else {
      res.status(200).json({
        user: rows,
        success: true,
        message: "All records list",
      });
    }
  } catch (error) {
    console.log("errr ", error);
    res.status(500).json({ success: false, message: "Error on request" });
  }
};

// GET  USER BY Id
const getUsersById = async (req, res) => {
  // console.log('REQ', req.params)
  // console.log('REQ', req.params.id)
  try {
    const userID = req.params.id;
    const [rows, fields] = await db.query(
      "SELECT * FROM user WHERE UserID = ?",
      [userID]
    );
    if (rows.length === 0) {
      res.status(200).json({ success: true, message: "User Not Found" });
    } else {
      res
        .status(200)
        .json({ user: rows[0], success: true, message: "Records Found" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Error on request" });
  }
};

// CREATE  USERS
// JSON object needs to be passed in request
// { first_name, last_name, user_email}
const createUser = async (req, res) => {
  try {
    const {
      first_name,
      last_name,
      user_email,
      user_password,
      user_name,
      user_role,
    } = req.body;

    const [rows, fields] = await db.query(
      `SELECT * FROM user WHERE UserName = ? OR UserEmail = ?`,
      [user_name, user_email]
    );
    if (!!rows.length) {
      return res.status(409).json({
        success: false,
        message: "User name or User email already exist.",
      });
    }

    const hashedPwd = await bcrypt.hash(user_password, 10);
    await db.query(
      "INSERT INTO user (FirstName, LastName, UserEmail, UserPassword, UserName, UserRoles) VALUES (?, ?, ?, ?, ?, ?)",
      [first_name, last_name, user_email, hashedPwd, user_name, user_role]
    );

    res.status(201).json({ success: true, message: "Records inserted." });
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Error on request" });
  }
};

// UPDATE USER BYID
const updateUserById = async (req, res) => {
  try {
    const { first_name, last_name, user_password, user_roles } = req.body;

    const userID = req.params.id;
    await db.query(
      `UPDATE user SET FirstName = ?, LastName = ?, UserPassword = ?, UserRoles = ?  WHERE UserID = ?`,
      [first_name, last_name, user_password, user_roles, userID]
    );
    res
      .status(200)
      .json({ success: true, message: "Records updated successfully." });
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Error on request" });
  }
};

// DELETE USER BYID
const delteUserById = async (req, res) => {
  try {
    const userID = req.params.id;
    const [rows, fields] = await db.query("DELETE FROM user WHERE UserID = ?", [
      userID,
    ]);

    // const rows = [0];

    if (rows.length === 0) {
      res.status(200).json({ success: true, message: "User Not Found" });
    } else {
      res.status(200).json({
        user: rows[0],
        success: true,
        message: "Records Deleted successful.",
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, message: "Error on request" });
  }
};

module.exports = {
  getUsersList,
  getUsersById,
  createUser,
  updateUserById,
  delteUserById,
};
