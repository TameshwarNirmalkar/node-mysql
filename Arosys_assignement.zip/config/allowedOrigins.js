const allowedOrigins = ["http://127.0.0.1:3011", "http://localhost:3011"];

module.exports = allowedOrigins;
