const ROLES_LIST = {
  Admin: 1001,
  Editor: 1002,
  User: 1003,
};

module.exports = ROLES_LIST;
