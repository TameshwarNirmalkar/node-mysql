const express = require("express");
const ROLES_LIST = require("../config/roles_list");
const verifyRoles = require("../middleware/verifyRoles");

const {
  getUsersList,
  getUsersById,
  createUser,
  updateUserById,
  delteUserById,
} = require("../controllers/usersController");

const router = express.Router();

router.get("/", getUsersList);
router.get("/:id", getUsersById);
router.post("/", createUser);
router.put(
  "/:id",
  verifyRoles(ROLES_LIST.Admin, ROLES_LIST.Editor),
  updateUserById
);
// verifyRoles(ROLES_LIST.Admin)
router.delete("/:id", delteUserById);

module.exports = router;
